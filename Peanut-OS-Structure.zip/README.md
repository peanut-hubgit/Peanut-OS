# PeanutOS 🥜

PeanutOS é um sistema operacional experimental executado como um aplicativo Android.

## Objetivos
- Interface inspirada no Android
- Boot Animation própria
- Launcher personalizado
- Runtime Python integrado
- Central de Controle
- Sistema de temas
- Loja Peanut (futuro)

## Estrutura

app/
apps/
assets/
bootanimation/
core/
docs/
launcher/
runtime-python/
scripts/
setupwizard/
systemui/
themes/
wallpapers/

## Status
🚧 Em desenvolvimento.
